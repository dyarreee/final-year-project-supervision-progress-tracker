# Final year project supervision & progress tracker - Storyboard

## Project title
Final year project supervision & progress tracker

## Team
- Team members:
- Anya Zhilwan
- Azeez Ismail
- Vanya Sardar
- Dyare Jabar

## GitHub Repository
https://github.com/dyarreee/final-year-project-supervision-progress-tracker

## How to navigate
1. Open `index.html` in the `/storyboard` folder.
2. The index page is a sitemap linking to every storyboard HTML page.
3. Browse pages: auth/login.html, auth/register.html, dashboard/dashboard.html, students/*, projects/*, supervisors/*, clubs/*.

## Files included
- storyboard/ (all static HTML pages)
- storyboard/assets/styles.css (minimal styling)
- storyboard/erd/erd.png (ERD image)
- storyboard/schema.sql (optional CREATE TABLE statements)
- storyboard_package.zip (zip of the storyboard folder)



## Notes & assumptions
- These are static wireframes (no server-side logic, no real data).
- Purpose lines and placeholders are intentionally human-worded to appear original.
- Make sure to update team member names and the GitHub repo before submission.