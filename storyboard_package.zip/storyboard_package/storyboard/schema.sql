-- schema.sql (suggested CREATE TABLE statements)

CREATE TABLE users (
  user_id SERIAL PRIMARY KEY,
  full_name VARCHAR(150) NOT NULL,
  email VARCHAR(200) NOT NULL UNIQUE,
  role VARCHAR(30) NOT NULL -- e.g. 'student', 'supervisor', 'admin'
);

CREATE TABLE students (
  student_id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(user_id),
  enrollment_no VARCHAR(50),
  program VARCHAR(100)
);

CREATE TABLE supervisors (
  supervisor_id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(user_id),
  department VARCHAR(100)
);

CREATE TABLE projects (
  project_id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  abstract TEXT,
  supervisor_id INTEGER REFERENCES supervisors(supervisor_id),
  status VARCHAR(50) -- e.g. 'proposed','active','completed'
);

CREATE TABLE project_members (
  id SERIAL PRIMARY KEY,
  project_id INTEGER REFERENCES projects(project_id),
  student_id INTEGER REFERENCES students(student_id),
  role_in_project VARCHAR(80)
);

CREATE TABLE progress_updates (
  update_id SERIAL PRIMARY KEY,
  project_id INTEGER REFERENCES projects(project_id),
  date DATE,
  milestone VARCHAR(255),
  status VARCHAR(50),
  remarks TEXT
);